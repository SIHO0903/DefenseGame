﻿public interface IDamage
{
    public float Damage { get; set; }
    public float AttackSpeed { get; set; }
    public float DetectRange { get; set; }
    public float AttackRange { get; set; }
}

