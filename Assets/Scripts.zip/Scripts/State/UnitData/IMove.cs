﻿public interface IMove
{
    public float MoveSpeed { get; set; }
    public MoveDir MoveDir { get; set; }
}

