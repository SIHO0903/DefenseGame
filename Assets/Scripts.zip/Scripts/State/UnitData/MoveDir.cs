﻿[System.Serializable]
public enum MoveDir
{
    MoveLeft  = -1,
    MoveRight =  1
}

