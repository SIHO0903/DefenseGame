﻿public interface ICastleObserver
{
    void OnCastleDestroyed(Castle castle);
}